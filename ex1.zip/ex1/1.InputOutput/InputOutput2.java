import java.util.*;
public class InputOutput2{
public static void main(String[] args){
int soap=5,paste=20,brush=10;
double price;
price=((soap*2)+paste+(brush*2));
System.out.println("Final bill: "+price);
}
}